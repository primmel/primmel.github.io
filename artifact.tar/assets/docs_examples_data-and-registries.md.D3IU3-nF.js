import{_ as s,o as e,c as t,a2 as n}from"./chunks/framework.BWuWLRhz.js";const u=JSON.parse('{"title":"Data and registries","description":"","frontmatter":{},"headers":[],"relativePath":"docs/examples/data-and-registries.md","filePath":"docs/examples/data-and-registries.md","lastUpdated":1782907982000}'),i={name:"docs/examples/data-and-registries.md"};function o(p,a,d,l,c,r){return e(),t("div",null,[...a[0]||(a[0]=[n(`<h1 id="data-and-registries" tabindex="-1">Data and registries <a class="header-anchor" href="#data-and-registries" aria-label="Permalink to &quot;Data and registries&quot;">​</a></h1><div class="tip custom-block"><p class="custom-block-title">Source file</p><p><a href="/docs/examples/files/02-data-and-registries.prl.html"><code>02-data-and-registries.prl</code></a></p></div><p>This example introduces the data side of Primmel. It models a small roastery logbook — bean lots received at the dock, batches roasted, batches inspected — with the registries that hold those records.</p><p>The flow is intentionally linear (<code>receive → roast → inspect</code>). The interesting part is the <strong>data layer</strong>, not the process layer.</p><h2 id="primitives-introduced" tabindex="-1">Primitives introduced <a class="header-anchor" href="#primitives-introduced" aria-label="Permalink to &quot;Primitives introduced&quot;">​</a></h2><table tabindex="0"><thead><tr><th>Primitive</th><th>Purpose</th></tr></thead><tbody><tr><td><code>enum</code></td><td>A closed set of named values (here: roast levels).</td></tr><tr><td><code>class#data</code></td><td>A typed record that can be linked to a registry. The <code>#data</code> suffix is the marker.</td></tr><tr><td>Helper <code>class</code> (no suffix)</td><td>A reusable complex type, embeddable inside other classes.</td></tr><tr><td><code>reference(Target#data)</code></td><td>A typed foreign-key field.</td></tr><tr><td><code>data_registry</code></td><td>A named store of records of a given data class.</td></tr><tr><td><code>output { ... }</code></td><td>A process clause: which registries this process writes to.</td></tr><tr><td><code>reference_data_registry { ... }</code></td><td>A process clause: which registries this process reads from.</td></tr></tbody></table><h2 id="enums" tabindex="-1">Enums <a class="header-anchor" href="#enums" aria-label="Permalink to &quot;Enums&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>enum RoastLevel {</span></span>
<span class="line"><span>  Light   { definition &quot;Light roast&quot; }</span></span>
<span class="line"><span>  Medium  { definition &quot;Medium roast&quot; }</span></span>
<span class="line"><span>  Dark    { definition &quot;Dark roast&quot; }</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>An <code>enum</code> is a closed set of named values, each with a definition. Use enums for any field whose value comes from a fixed list.</p><h2 id="data-classes-with-data" tabindex="-1">Data classes (with <code>#data</code>) <a class="header-anchor" href="#data-classes-with-data" aria-label="Permalink to &quot;Data classes (with \`#data\`)&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>class BeanLot#data {</span></span>
<span class="line"><span>  lot_id:           string   { definition &quot;Supplier lot identifier&quot;; modality SHALL }</span></span>
<span class="line"><span>  origin:           string   { definition &quot;Country or region of origin&quot;; modality SHALL }</span></span>
<span class="line"><span>  received_on:      datetime { definition &quot;Date received at the roastery&quot;; modality SHALL }</span></span>
<span class="line"><span>  certified_organic: boolean { definition &quot;Whether the lot is certified organic&quot;; modality MAY }</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>Every field has:</p><ul><li>A name (<code>lot_id</code>).</li><li>A type (<code>string</code>, <code>datetime</code>, <code>boolean</code>, an <code>enum</code> name, a <code>reference(...)</code>, a <code>role</code>, or another class).</li><li>A block with at least a <code>definition</code> (the human-readable meaning of the field) and a <code>modality</code> (<code>SHALL</code>/<code>SHOULD</code>/<code>MAY</code>/<code>CAN</code>/<code>MUST</code>).</li></ul><p>The <code>#data</code> suffix marks this class as registerable — you can put records of this shape into a <code>data_registry</code>. Without the suffix, the class is a helper (see below).</p><h2 id="helper-classes-without-data" tabindex="-1">Helper classes (without <code>#data</code>) <a class="header-anchor" href="#helper-classes-without-data" aria-label="Permalink to &quot;Helper classes (without \`#data\`)&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>class RoastProfile {</span></span>
<span class="line"><span>  name             { definition &quot;Profile name (e.g. City+, Full City)&quot; }</span></span>
<span class="line"><span>  target_level:    RoastLevel { definition &quot;Target roast level&quot; }</span></span>
<span class="line"><span>  development_time: string    { definition &quot;Target development time in seconds&quot; }</span></span>
<span class="line"><span>  notes            { definition &quot;Roaster&#39;s notes&quot; }</span></span>
<span class="line"><span>}</span></span></code></pre></div><p><code>RoastProfile</code> is a complex type that lives <strong>inside</strong> other data classes. It cannot be registered directly — there is no <code>RoastProfileRegistry</code>. Instead, it appears as a field on <code>RoastBatch#data</code>:</p><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>class RoastBatch#data {</span></span>
<span class="line"><span>  batch_id:    string                            { ... }</span></span>
<span class="line"><span>  lot:         reference(BeanLot#data)           { ... }</span></span>
<span class="line"><span>  profile:     RoastProfile                      { definition &quot;Roast profile applied&quot; }</span></span>
<span class="line"><span>  roast_level: RoastLevel                        { ... }</span></span>
<span class="line"><span>  roast_date:  datetime                          { ... }</span></span>
<span class="line"><span>  moisture_pct: string                           { ... }</span></span>
<span class="line"><span>  roasted_by:  role                              { ... }</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>This distinction matters: only <code>class#data</code> declarations appear in registries. Helper classes are how you build composite field types.</p><h2 id="references" tabindex="-1">References <a class="header-anchor" href="#references" aria-label="Permalink to &quot;References&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>lot: reference(BeanLot#data) {</span></span>
<span class="line"><span>  definition &quot;Bean lot used for this batch&quot;</span></span>
<span class="line"><span>  modality SHALL</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>A <code>reference(Target#data)</code> field is a typed foreign key. It points at another record in another registry. At evaluation time, tooling follows these references to traverse the data graph — e.g. from a <code>RoastBatch</code> to the <code>BeanLot</code> it was roasted from.</p><p>The <code>role</code> type (used by <code>roasted_by</code>) is a special reference to a person in a role, rather than to another data record.</p><h2 id="data-registries" tabindex="-1">Data registries <a class="header-anchor" href="#data-registries" aria-label="Permalink to &quot;Data registries&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>data_registry BeanLotRegistry {</span></span>
<span class="line"><span>  title &quot;Bean lots&quot;</span></span>
<span class="line"><span>  data_class BeanLot#data</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>data_registry RoastBatchRegistry {</span></span>
<span class="line"><span>  title &quot;Roast batch logbook&quot;</span></span>
<span class="line"><span>  data_class RoastBatch#data</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>A <code>data_registry</code> is a named store of records. It declares which <code>class#data</code> shape its records conform to. registries are the things that processes read from (<code>reference_data_registry</code>) and write to (<code>output</code>).</p><h2 id="processes-that-read-and-write-data" tabindex="-1">Processes that read and write data <a class="header-anchor" href="#processes-that-read-and-write-data" aria-label="Permalink to &quot;Processes that read and write data&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>process ReceiveBeans {</span></span>
<span class="line"><span>  name &quot;Receive a bean lot from an approved supplier&quot;</span></span>
<span class="line"><span>  actor Roaster</span></span>
<span class="line"><span>  output {</span></span>
<span class="line"><span>    BeanLotRegistry</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>process RoastBatch {</span></span>
<span class="line"><span>  name &quot;Roast a batch of beans&quot;</span></span>
<span class="line"><span>  actor Roaster</span></span>
<span class="line"><span>  reference_data_registry {</span></span>
<span class="line"><span>    BeanLotRegistry</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>  output {</span></span>
<span class="line"><span>    RoastBatchRegistry</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>process InspectBatch {</span></span>
<span class="line"><span>  name &quot;Inspect a roasted batch&quot;</span></span>
<span class="line"><span>  actor QA</span></span>
<span class="line"><span>  reference_data_registry {</span></span>
<span class="line"><span>    RoastBatchRegistry</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span></code></pre></div><table tabindex="0"><thead><tr><th>Process</th><th>Reads</th><th>Writes</th></tr></thead><tbody><tr><td><code>ReceiveBeans</code></td><td>—</td><td><code>BeanLotRegistry</code></td></tr><tr><td><code>RoastBatch</code></td><td><code>BeanLotRegistry</code></td><td><code>RoastBatchRegistry</code></td></tr><tr><td><code>InspectBatch</code></td><td><code>RoastBatchRegistry</code></td><td>—</td></tr></tbody></table><p>The data flows down the chain. Each registry becomes the join point between the process that produces its records and the process that consumes them.</p><h2 id="the-diagram" tabindex="-1">The diagram <a class="header-anchor" href="#the-diagram" aria-label="Permalink to &quot;The diagram&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>subprocess Root {</span></span>
<span class="line"><span>  elements {</span></span>
<span class="line"><span>    Start1      { x 0    y 0 }</span></span>
<span class="line"><span>    ReceiveBeans { x -100 y 100 }</span></span>
<span class="line"><span>    RoastBatch   { x -100 y 200 }</span></span>
<span class="line"><span>    InspectBatch { x -100 y 300 }</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>  process_flow {</span></span>
<span class="line"><span>    Edge1 { from Start1      to ReceiveBeans }</span></span>
<span class="line"><span>    Edge2 { from ReceiveBeans to RoastBatch }</span></span>
<span class="line"><span>    Edge3 { from RoastBatch   to InspectBatch }</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>  data {</span></span>
<span class="line"><span>    BeanLotRegistry   { x 150 y 130 }</span></span>
<span class="line"><span>    RoastBatchRegistry { x 150 y 230 }</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>The <code>data { ... }</code> block places the registries on the diagram at the given coordinates. Visually, the registries sit to the right of the process flow, indicating that they are external to the flow itself but referenced by it.</p><h2 id="what-this-example-leaves-out" tabindex="-1">What this example leaves out <a class="header-anchor" href="#what-this-example-leaves-out" aria-label="Permalink to &quot;What this example leaves out&quot;">​</a></h2><ul><li><strong>Compliance</strong> — no <code>provision</code>, no <code>modality</code> on processes. Added in <a href="/docs/examples/compliance-and-measurement.html">compliance and measurement</a>.</li><li><strong>Branching</strong> — the flow is a straight line. Branching is added in <a href="/docs/examples/process-flow.html">process flow</a>.</li><li><strong>Subject bindings</strong> — provisions that evaluate against registry records. Added in <a href="/docs/examples/compliance-and-measurement.html">compliance and measurement</a>.</li></ul>`,35)])])}const g=s(i,[["render",o]]);export{u as __pageData,g as default};
