import{_ as e,o as s,c as n,a2 as t}from"./chunks/framework.BWuWLRhz.js";const m=JSON.parse('{"title":"Measurement","description":"","frontmatter":{},"headers":[],"relativePath":"docs/measurement.md","filePath":"docs/measurement.md","lastUpdated":1782907982000}'),p={name:"docs/measurement.md"};function o(i,a,l,r,c,d){return s(),n("div",null,[...a[0]||(a[0]=[t(`<h1 id="measurement" tabindex="-1">Measurement <a class="header-anchor" href="#measurement" aria-label="Permalink to &quot;Measurement&quot;">​</a></h1><p>Primmel supports quantitative monitoring via the <strong>measurement</strong> primitive. Measurements are how a model becomes <em>numerically</em> testable: they declare the values that <code>validate_measurement</code> expressions and gateway <code>condition</code>s evaluate against.</p><h2 id="measurement-types" tabindex="-1">Measurement types <a class="header-anchor" href="#measurement-types" aria-label="Permalink to &quot;Measurement types&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>measurement MoistureReading {</span></span>
<span class="line"><span>  type DATALIST</span></span>
<span class="line"><span>  description &quot;Per-batch moisture readings in percent by mass&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement MaxMoisture {</span></span>
<span class="line"><span>  type DERIVED</span></span>
<span class="line"><span>  definition &quot;[MoistureReading].max&quot;</span></span>
<span class="line"><span>  description &quot;Highest moisture reading across all batches&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement RequiredGrade {</span></span>
<span class="line"><span>  type TEXT</span></span>
<span class="line"><span>  description &quot;Contractual freshness grade (A, B, or C)&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement RequiredMaxMoisture {</span></span>
<span class="line"><span>  type TABLE_REFERENCE</span></span>
<span class="line"><span>  definition &quot;FreshnessGradeTable,1,0,2&quot;</span></span>
<span class="line"><span>  description &quot;Maximum moisture percent for the required grade&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement ContractThreshold {</span></span>
<span class="line"><span>  type NUMERIC</span></span>
<span class="line"><span>  description &quot;Contractual maximum moisture percent&quot;</span></span>
<span class="line"><span>}</span></span></code></pre></div><table tabindex="0"><thead><tr><th><code>type</code></th><th>Meaning</th></tr></thead><tbody><tr><td><code>DATALIST</code></td><td>A list of raw readings (e.g. one per batch).</td></tr><tr><td><code>DERIVED</code></td><td>A value computed from another measurement via <code>[Other].max</code>, <code>.min</code>, <code>.average</code>, <code>.count</code>.</td></tr><tr><td><code>TEXT</code></td><td>A free-form text value.</td></tr><tr><td><code>NUMERIC</code></td><td>A single numeric value.</td></tr><tr><td><code>TABLE_REFERENCE</code></td><td>A value looked up in a <code>table</code> by <code>TableName,row_query,column_index</code>.</td></tr></tbody></table><h2 id="derived-expressions" tabindex="-1">DERIVED expressions <a class="header-anchor" href="#derived-expressions" aria-label="Permalink to &quot;DERIVED expressions&quot;">​</a></h2><p>A <code>DERIVED</code> measurement references other measurements with the <code>[MeasurementName]</code> syntax:</p><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>measurement MaxMoisture {</span></span>
<span class="line"><span>  type DERIVED</span></span>
<span class="line"><span>  definition &quot;[MoistureReading].max&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement AvgMoisture {</span></span>
<span class="line"><span>  type DERIVED</span></span>
<span class="line"><span>  definition &quot;[MoistureReading].average&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement TotalTestedBatchCount {</span></span>
<span class="line"><span>  type DERIVED</span></span>
<span class="line"><span>  definition &quot;[MoistureReading].count&quot;</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>Supported aggregates: <code>.max</code>, <code>.min</code>, <code>.average</code>, <code>.count</code>.</p><h2 id="table-reference-lookups" tabindex="-1">TABLE_REFERENCE lookups <a class="header-anchor" href="#table-reference-lookups" aria-label="Permalink to &quot;TABLE_REFERENCE lookups&quot;">​</a></h2><p>A <code>TABLE_REFERENCE</code> measurement looks up a cell in a declared <code>table</code>:</p><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>table FreshnessGradeTable {</span></span>
<span class="line"><span>  title &quot;Freshness grade lookup&quot;</span></span>
<span class="line"><span>  columns &quot;3&quot;</span></span>
<span class="line"><span>  data {</span></span>
<span class="line"><span>    &quot;grade&quot; &quot;threshold_pct&quot; &quot;description&quot;</span></span>
<span class="line"><span>    &quot;A&quot;     &quot;10&quot;             &quot;Premium freshness&quot;</span></span>
<span class="line"><span>    &quot;B&quot;     &quot;11&quot;             &quot;Standard freshness&quot;</span></span>
<span class="line"><span>    &quot;C&quot;     &quot;12&quot;             &quot;Acceptable freshness&quot;</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement RequiredMaxMoisture {</span></span>
<span class="line"><span>  type TABLE_REFERENCE</span></span>
<span class="line"><span>  definition &quot;FreshnessGradeTable,1,0,2&quot;</span></span>
<span class="line"><span>  description &quot;Maximum moisture percent for the required grade&quot;</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>The <code>definition</code> syntax is <code>TableName,row_query,column_index</code>. The runtime uses the row query to find the right row and the column index to pick the cell.</p><h2 id="where-measurements-are-evaluated" tabindex="-1">Where measurements are evaluated <a class="header-anchor" href="#where-measurements-are-evaluated" aria-label="Permalink to &quot;Where measurements are evaluated&quot;">​</a></h2><h3 id="validate-measurement-on-a-process" tabindex="-1"><code>validate_measurement</code> on a process <a class="header-anchor" href="#validate-measurement-on-a-process" aria-label="Permalink to &quot;\`validate_measurement\` on a process&quot;">​</a></h3><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>process TestMoisture {</span></span>
<span class="line"><span>  modality SHALL</span></span>
<span class="line"><span>  validate_measurement {</span></span>
<span class="line"><span>    &quot;[MaxMoisture] &lt;= 12&quot;</span></span>
<span class="line"><span>    &quot;[MinMoisture] &gt;= 8&quot;</span></span>
<span class="line"><span>    &quot;[MaxMoisture] &lt;= [RequiredMaxMoisture]&quot;</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>  reference_data_registry {</span></span>
<span class="line"><span>    RoastBatchRegistry</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>Each expression is a predicate over measurements. The process passes its compliance check if and only if all of them hold.</p><h3 id="gateway-edge-condition" tabindex="-1">Gateway edge <code>condition</code> <a class="header-anchor" href="#gateway-edge-condition" aria-label="Permalink to &quot;Gateway edge \`condition\`&quot;">​</a></h3><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>Edge3 {</span></span>
<span class="line"><span>  from MoistureGateway</span></span>
<span class="line"><span>  to Pass</span></span>
<span class="line"><span>  description &quot;Moisture is within the required threshold&quot;</span></span>
<span class="line"><span>  condition &quot;[MaxMoisture] &lt;= [RequiredMaxMoisture]&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span>Edge5 {</span></span>
<span class="line"><span>  from MoistureGateway</span></span>
<span class="line"><span>  to Fail</span></span>
<span class="line"><span>  description &quot;default&quot;</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>The runtime evaluates each non-default edge&#39;s <code>condition</code> in order; the first one that holds is taken. If none hold, the <code>&quot;default&quot;</code> edge is taken.</p><h2 id="where-to-see-it-in-action" tabindex="-1">Where to see it in action <a class="header-anchor" href="#where-to-see-it-in-action" aria-label="Permalink to &quot;Where to see it in action&quot;">​</a></h2><ul><li><a href="/docs/examples/compliance-and-measurement.html">Example 04: Compliance and measurement</a> — the dedicated walkthrough, including all five measurement types.</li><li><a href="/docs/examples/implementation-package.html">Implementation package</a> — measurements at production scale with actual readings in a <code>.pws</code> workspace.</li></ul>`,22)])])}const h=e(p,[["render",o]]);export{m as __pageData,h as default};
