import{_ as a,o as e,c as n,a2 as t}from"./chunks/framework.BWuWLRhz.js";const h=JSON.parse('{"title":"Compliance and measurement","description":"","frontmatter":{},"headers":[],"relativePath":"docs/examples/compliance-and-measurement.md","filePath":"docs/examples/compliance-and-measurement.md","lastUpdated":1782907982000}'),o={name:"docs/examples/compliance-and-measurement.md"};function p(i,s,c,l,d,r){return e(),n("div",null,[...s[0]||(s[0]=[t(`<h1 id="compliance-and-measurement" tabindex="-1">Compliance and measurement <a class="header-anchor" href="#compliance-and-measurement" aria-label="Permalink to &quot;Compliance and measurement&quot;">​</a></h1><div class="tip custom-block"><p class="custom-block-title">Source file</p><p><a href="/docs/examples/files/04-compliance-and-measurement.prl.html"><code>04-compliance-and-measurement.prl</code></a></p></div><p>This example is where Primmel stops being just a flowchart tool and becomes a compliance engine. A fictional bean-freshness programme binds quality provisions to derived measurements, with a gateway whose outgoing edges carry <strong>machine-readable conditions</strong>.</p><p>This is the pattern that lets an auditor answer the question <em>&quot;which of these batches comply, and which don&#39;t?&quot;</em> by following the model structurally.</p><h2 id="primitives-introduced" tabindex="-1">Primitives introduced <a class="header-anchor" href="#primitives-introduced" aria-label="Permalink to &quot;Primitives introduced&quot;">​</a></h2><table tabindex="0"><thead><tr><th>Primitive</th><th>Purpose</th></tr></thead><tbody><tr><td><code>provision</code> with <code>modality</code></td><td>A requirement with RFC 2119 weight (<code>SHALL</code> / <code>SHOULD</code> / <code>MAY</code>).</td></tr><tr><td><code>subject#N</code> binding</td><td>Bind a provision to a registry so its evaluation is data-aware.</td></tr><tr><td><code>reference</code></td><td>Cite an external document clause that the provision traces back to.</td></tr><tr><td><code>note</code></td><td>A NOTE annotation tied to a clause.</td></tr><tr><td><code>table</code></td><td>A lookup table used by <code>TABLE_REFERENCE</code> measurements.</td></tr><tr><td><code>measurement</code> (<code>DATALIST</code>)</td><td>A list of raw readings.</td></tr><tr><td><code>measurement</code> (<code>DERIVED</code>)</td><td>A value computed from other measurements (<code>max</code>, <code>min</code>, <code>average</code>, <code>count</code>).</td></tr><tr><td><code>measurement</code> (<code>TEXT</code>)</td><td>A free-form text value.</td></tr><tr><td><code>measurement</code> (<code>NUMERIC</code>)</td><td>A single numeric value.</td></tr><tr><td><code>measurement</code> (<code>TABLE_REFERENCE</code>)</td><td>A value looked up in a <code>table</code> by row/column.</td></tr><tr><td><code>validate_provision</code></td><td>A process clause: the provisions this process must satisfy.</td></tr><tr><td><code>validate_measurement</code></td><td>A process clause: the measurement expressions that must hold.</td></tr><tr><td>Gateway edge <code>condition</code></td><td>A machine-readable measurement expression on a gateway outgoing edge.</td></tr></tbody></table><h2 id="references" tabindex="-1">References <a class="header-anchor" href="#references" aria-label="Permalink to &quot;References&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>reference BFS-4-2 {</span></span>
<span class="line"><span>  document &quot;Bean Freshness Standard (fictional)&quot;</span></span>
<span class="line"><span>  clause &quot;4.2&quot;</span></span>
<span class="line"><span>  title &quot;Moisture content&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>reference BFS-4-2-note {</span></span>
<span class="line"><span>  document &quot;Bean Freshness Standard (fictional)&quot;</span></span>
<span class="line"><span>  clause &quot;4.2 NOTE&quot;</span></span>
<span class="line"><span>  title &quot;Moisture measurement tolerance&quot;</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>A <code>reference</code> is a pointer to an external document clause. The <code>document</code> names the source; <code>clause</code> cites the section; <code>title</code> is a short label. A reference is what a <code>provision</code> cites to justify its existence.</p><p>In a real workspace, references typically point at clauses in a <code>.prd</code> file (source document content). See the <a href="/docs/examples/implementation-package.html">implementation package</a> for that pattern.</p><h2 id="provisions" tabindex="-1">Provisions <a class="header-anchor" href="#provisions" aria-label="Permalink to &quot;Provisions&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>provision MoistureRecorded {</span></span>
<span class="line"><span>  condition &quot;Every roast batch shall have its moisture content recorded&quot;</span></span>
<span class="line"><span>  modality SHALL</span></span>
<span class="line"><span>  reference {</span></span>
<span class="line"><span>    BFS-4-2</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>provision MoistureWithinRange {</span></span>
<span class="line"><span>  condition &quot;Moisture content shall be between 8 percent and 12 percent by mass&quot;</span></span>
<span class="line"><span>  modality SHALL</span></span>
<span class="line"><span>  reference {</span></span>
<span class="line"><span>    BFS-4-2</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>A provision has:</p><ul><li>A <code>condition</code> — the human-readable requirement.</li><li>A <code>modality</code> — <code>SHALL</code>, <code>SHOULD</code>, <code>MAY</code>, <code>CAN</code>, or <code>MUST</code> (RFC 2119).</li><li>A <code>reference { ... }</code> block — the clauses this provision derives from.</li></ul><h3 id="subject-bindings" tabindex="-1">Subject bindings <a class="header-anchor" href="#subject-bindings" aria-label="Permalink to &quot;Subject bindings&quot;">​</a></h3><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>provision StandardMeetFreshness {</span></span>
<span class="line"><span>  subject#1 RoastBatchRegistry</span></span>
<span class="line"><span>  condition &quot;{ Roast batches (Data) } selected meet the freshness requirements&quot;</span></span>
<span class="line"><span>  modality SHALL</span></span>
<span class="line"><span>  reference {</span></span>
<span class="line"><span>    BFS-4-2</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>The <code>subject#1 RoastBatchRegistry</code> line binds this provision&#39;s evaluation to records in <code>RoastBatchRegistry</code>. The <code>{ Roast batches (Data) }</code> placeholder in the condition text is replaced at evaluation time by the actual records of the bound registry. This is what makes the provision <strong>data-aware</strong>.</p><p>A provision can have multiple subject bindings (<code>subject#1</code>, <code>subject#2</code>, etc.), each bound to a different registry.</p><h2 id="notes" tabindex="-1">Notes <a class="header-anchor" href="#notes" aria-label="Permalink to &quot;Notes&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>note MoistureNote {</span></span>
<span class="line"><span>  type NOTE</span></span>
<span class="line"><span>  message &quot;The moisture tolerance reflects typical commercial storage conditions; tighter tolerances may apply for export-grade stock.&quot;</span></span>
<span class="line"><span>  reference {</span></span>
<span class="line"><span>    BFS-4-2-note</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>A <code>note</code> is an annotation. The <code>type</code> is typically <code>NOTE</code> or <code>EXAMPLE</code>, mirroring the annotation vocabulary of formal standards documents. Notes are referenced by processes via <code>note { ... }</code>.</p><h2 id="tables" tabindex="-1">Tables <a class="header-anchor" href="#tables" aria-label="Permalink to &quot;Tables&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>table FreshnessGradeTable {</span></span>
<span class="line"><span>  title &quot;Freshness grade lookup&quot;</span></span>
<span class="line"><span>  columns &quot;3&quot;</span></span>
<span class="line"><span>  display &quot;[grade]: [threshold_pct]&quot;</span></span>
<span class="line"><span>  domain { }</span></span>
<span class="line"><span>  data {</span></span>
<span class="line"><span>    &quot;grade&quot; &quot;threshold_pct&quot; &quot;description&quot;</span></span>
<span class="line"><span>    &quot;A&quot; &quot;10&quot; &quot;Premium freshness&quot;</span></span>
<span class="line"><span>    &quot;B&quot; &quot;11&quot; &quot;Standard freshness&quot;</span></span>
<span class="line"><span>    &quot;C&quot; &quot;12&quot; &quot;Acceptable freshness&quot;</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>A <code>table</code> is a lookup table. The first row of <code>data</code> is the header; the remaining rows are values. Tables are referenced by <code>TABLE_REFERENCE</code> measurements (see below) to look up specific cells.</p><h2 id="measurements" tabindex="-1">Measurements <a class="header-anchor" href="#measurements" aria-label="Permalink to &quot;Measurements&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>measurement MoistureReading {</span></span>
<span class="line"><span>  type DATALIST</span></span>
<span class="line"><span>  description &quot;Per-batch moisture readings in percent by mass&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement MaxMoisture {</span></span>
<span class="line"><span>  type DERIVED</span></span>
<span class="line"><span>  definition &quot;[MoistureReading].max&quot;</span></span>
<span class="line"><span>  description &quot;Highest moisture reading across all batches&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement MinMoisture {</span></span>
<span class="line"><span>  type DERIVED</span></span>
<span class="line"><span>  definition &quot;[MoistureReading].min&quot;</span></span>
<span class="line"><span>  description &quot;Lowest moisture reading across all batches&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement AvgMoisture {</span></span>
<span class="line"><span>  type DERIVED</span></span>
<span class="line"><span>  definition &quot;[MoistureReading].average&quot;</span></span>
<span class="line"><span>  description &quot;Average moisture reading across all batches&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement TotalTestedBatchCount {</span></span>
<span class="line"><span>  type DERIVED</span></span>
<span class="line"><span>  definition &quot;[MoistureReading].count&quot;</span></span>
<span class="line"><span>  description &quot;Number of batches with a moisture reading on file&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement RequiredGrade {</span></span>
<span class="line"><span>  type TEXT</span></span>
<span class="line"><span>  description &quot;Contractual freshness grade (A, B, or C)&quot;</span></span>
<span class="line"><span>}</span></span>
<span class="line"><span></span></span>
<span class="line"><span>measurement RequiredMaxMoisture {</span></span>
<span class="line"><span>  type TABLE_REFERENCE</span></span>
<span class="line"><span>  definition &quot;FreshnessGradeTable,1,0,2&quot;</span></span>
<span class="line"><span>  description &quot;Maximum moisture percent for the required grade&quot;</span></span>
<span class="line"><span>}</span></span></code></pre></div><table tabindex="0"><thead><tr><th><code>type</code></th><th>Meaning</th></tr></thead><tbody><tr><td><code>DATALIST</code></td><td>A list of raw readings (e.g. one per batch).</td></tr><tr><td><code>DERIVED</code></td><td>A value computed from another measurement via <code>[Other].max</code>, <code>.min</code>, <code>.average</code>, <code>.count</code>.</td></tr><tr><td><code>TEXT</code></td><td>A free-form text value.</td></tr><tr><td><code>NUMERIC</code></td><td>A single numeric value.</td></tr><tr><td><code>TABLE_REFERENCE</code></td><td>A value looked up in a <code>table</code> by <code>TableName,row_query,column_index</code>.</td></tr></tbody></table><p>A <code>DERIVED</code> measurement references other measurements using the <code>[MeasurementName]</code> syntax inside its <code>definition</code>. The same syntax is used in <code>validate_measurement</code> expressions and gateway edge <code>condition</code>s.</p><h2 id="processes-that-validate" tabindex="-1">Processes that validate <a class="header-anchor" href="#processes-that-validate" aria-label="Permalink to &quot;Processes that validate&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>process TestMoisture {</span></span>
<span class="line"><span>  name &quot;Test moisture content of a roast batch&quot;</span></span>
<span class="line"><span>  actor QA</span></span>
<span class="line"><span>  modality SHALL</span></span>
<span class="line"><span>  validate_provision {</span></span>
<span class="line"><span>    MoistureRecorded</span></span>
<span class="line"><span>    MoistureWithinRange</span></span>
<span class="line"><span>    StandardMeetFreshness</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>  validate_measurement {</span></span>
<span class="line"><span>    &quot;[MaxMoisture] &lt;= 12&quot;</span></span>
<span class="line"><span>    &quot;[MinMoisture] &gt;= 8&quot;</span></span>
<span class="line"><span>    &quot;[MaxMoisture] &lt;= [RequiredMaxMoisture]&quot;</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>  reference_data_registry {</span></span>
<span class="line"><span>    RoastBatchRegistry</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>  note {</span></span>
<span class="line"><span>    MoistureNote</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>A compliance-carrying process has three new clauses:</p><table tabindex="0"><thead><tr><th>Clause</th><th>Meaning</th></tr></thead><tbody><tr><td><code>modality SHALL</code></td><td>This process is mandatory.</td></tr><tr><td><code>validate_provision { ... }</code></td><td>The provisions this process must satisfy.</td></tr><tr><td><code>validate_measurement { ... }</code></td><td>The measurement expressions that must hold for the process to pass.</td></tr><tr><td><code>note { ... }</code></td><td>Notes attached to this process.</td></tr></tbody></table><p>The <code>validate_measurement</code> block is where the model becomes executable. Each expression is a predicate over measurements; the process passes its compliance check if and only if all of them hold.</p><h2 id="gateway-conditions" tabindex="-1">Gateway conditions <a class="header-anchor" href="#gateway-conditions" aria-label="Permalink to &quot;Gateway conditions&quot;">​</a></h2><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>process_flow {</span></span>
<span class="line"><span>  Edge1 { from Start1         to TestMoisture }</span></span>
<span class="line"><span>  Edge2 { from TestMoisture   to MoistureGateway }</span></span>
<span class="line"><span>  Edge3 {</span></span>
<span class="line"><span>    from MoistureGateway</span></span>
<span class="line"><span>    to Pass</span></span>
<span class="line"><span>    description &quot;Moisture is within the required threshold&quot;</span></span>
<span class="line"><span>    condition &quot;[MaxMoisture] &lt;= [RequiredMaxMoisture]&quot;</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>  Edge4 {</span></span>
<span class="line"><span>    from MoistureGateway</span></span>
<span class="line"><span>    to SellAgedStock</span></span>
<span class="line"><span>    description &quot;Batch is aged but still marketable&quot;</span></span>
<span class="line"><span>    condition &quot;[MaxMoisture] &lt;= 12&quot;</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>  Edge5 {</span></span>
<span class="line"><span>    from MoistureGateway</span></span>
<span class="line"><span>    to Fail</span></span>
<span class="line"><span>    description &quot;default&quot;</span></span>
<span class="line"><span>  }</span></span>
<span class="line"><span>}</span></span></code></pre></div><p>Each gateway edge can carry both:</p><ul><li>A <code>description</code> — what a human reads on the diagram.</li><li>A <code>condition</code> — a measurement expression that the runtime evaluates to decide whether this edge is taken.</li></ul><p>The edge marked <code>description &quot;default&quot;</code> is the fallback when none of the other edges&#39; conditions hold.</p><p>This is how a Primmel model encodes <em>decision logic</em> in a way that an auditor or test harness can replay against real data.</p><h2 id="what-this-example-leaves-out" tabindex="-1">What this example leaves out <a class="header-anchor" href="#what-this-example-leaves-out" aria-label="Permalink to &quot;What this example leaves out&quot;">​</a></h2><ul><li><strong>Cross-model aliasing</strong> — provisions live entirely inside this file. Cross-model aliasing is added in the <a href="/docs/examples/implementation-package.html">implementation package</a>.</li><li><strong>Workspace data</strong> — the model declares measurements but does not carry any actual readings. Workspace data is added in the <a href="/docs/examples/implementation-package.html">implementation package</a>.</li><li><strong>Approval steps</strong> — see <a href="/docs/examples/approval-workflow.html">approval workflow</a>.</li></ul>`,41)])])}const m=a(o,[["render",p]]);export{h as __pageData,m as default};
